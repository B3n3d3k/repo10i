class Termek:
    def __init__(self, nev, nettoAr):
        self.nev= nev
        self.nettoAr = nettoAr
    def bruttoArKiszamol(self):
        return self.nettoAr*1.27

